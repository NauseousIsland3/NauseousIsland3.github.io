
.. _settings_api:

Document |Settings| objects
---------------------------

.. currentmodule:: docx.settings

.. autoclass:: Settings()
   :members:
   :inherited-members:
   :exclude-members:
       part
